import { Injectable } from '@angular/core';
import { Course } from './course.model';
import { Resource } from './resource.model';
import { HttpClient,HttpHeaders } from '@angular/common/http';
import { Observable, of } from "rxjs";
import { environment } from 'src/environments/environment';
@Injectable({
  providedIn: 'root'
})
export class UpdateServiceService {
  private apiUrl: string = environment.apiUrl;
  Course: Course= new Course();
  Resource: Resource= new Resource();
  constructor(private httpClient: HttpClient) { }

  public update(controller:string,record:any): Observable<any>{
    const httpOptions = {
      headers: new HttpHeaders({
        "Content-Type": "application/json",
      }),
    };
    return this.httpClient.put<any>(
      `${this.apiUrl}${controller}`,
      record
    );
  }
}
