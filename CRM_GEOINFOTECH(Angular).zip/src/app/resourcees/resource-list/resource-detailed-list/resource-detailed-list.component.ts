import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-resource-detailed-list',
  templateUrl: './resource-detailed-list.component.html',
  styleUrls: ['./resource-detailed-list.component.css']
})
export class ResourceDetailedListComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
