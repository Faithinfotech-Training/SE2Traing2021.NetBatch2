import { Pipe, PipeTransform } from '@angular/core';
@Pipe({
    name:'rsearch'
})
export class ResourceSearchPipe implements PipeTransform {
    transform(languages: any, searchInput: string): any[]{     
        if(!searchInput) {
            return  languages;
        }
       searchInput = searchInput.toLowerCase();
       return languages.filter(
           x =>x.resourceName.toLowerCase().includes(searchInput)
       )
     }
}
