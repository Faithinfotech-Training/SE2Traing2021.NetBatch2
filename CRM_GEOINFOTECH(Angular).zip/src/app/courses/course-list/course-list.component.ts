import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CourseEnquiryService } from 'src/app/shared/course-enquiry.service';
import { CourseService } from 'src/app/shared/course.service';
import { UpdateServiceService } from 'src/app/shared/update-service.service';
import { __assign } from 'tslib';


@Component({
  selector: 'app-course-list',
  templateUrl: './course-list.component.html',
  styleUrls: ['./course-list.component.css']
})
export class CourseListComponent implements OnInit {

  course: any;
  searchInput:String='';
  constructor(public service:CourseService, private enquiryService: CourseEnquiryService,
     private router: Router, private updateservice: UpdateServiceService) { }

  ngOnInit(): void {
    this.service.getCourse().subscribe(res=>{
      this.course=res;
       console.log(res);
    });
  }
  populate(id:number, name:String):void{
    
    this.enquiryService.CourseEnquiry.CourseId=id;
    this.enquiryService.courseName=name;
    this.router.navigateByUrl('courseEnquiries/courseEnquiry')
    
    
  }
  update(course:any):void{
    this.updateservice.Course.CourseId= course.courseId;
    this.updateservice.Course.CourseName= course.courseName;
    this.updateservice.Course.CourseDesc= course.courseDesc;
    this.updateservice.Course.CourseDuration= course.courseDuration;
    this.updateservice.Course.CoursePrice= course.coursePrice;
    this.updateservice.Course.CourseAvailability= course.courseAvailability;
  }
}
