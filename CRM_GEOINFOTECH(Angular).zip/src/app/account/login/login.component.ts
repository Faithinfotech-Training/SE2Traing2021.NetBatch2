import { Component, OnInit } from "@angular/core";
import { Router, ActivatedRoute } from "@angular/router";
import { Login } from "./Login";
import { SecurityService } from "src/app/security/security.service";
import { AccountService } from "../account.service";
import { InsightService } from "src/app/manager/insights/insights.service";
@Component({
  selector: "app-login",
  templateUrl: "./login.component.html",
  styleUrls: ["./login.component.css"],
})
export class LoginComponent implements OnInit {
  constructor(
    private router: Router,
    private securityService: SecurityService,
    private activatedRoute: ActivatedRoute,
    private service: AccountService,
    private insight: InsightService
  ) {}
  loginViewModel: Login;
  Login(): void {
    
    
      
    this.securityService.Login(this.loginViewModel).subscribe(
      (item) => {
        localStorage.setItem('token',item.accessToken);
        this.router.navigateByUrl('/dashBoard');
        
        
      },
      (error) => {
        alert("invalid username or password");
        console.log(error);
      }
    );
    
  }
  ngOnInit(): void {
    this.loginViewModel = { UserName: "", Password: "" };
    this.insight.Visited("Login").subscribe(
      (item) => {
        
      },
      (error) => {
        alert("PageVisits Error occured");
      }
      );
   
  }
}



/*import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}*/
