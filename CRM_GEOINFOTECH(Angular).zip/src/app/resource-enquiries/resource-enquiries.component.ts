import { Component, OnInit } from '@angular/core';
import { InsightService } from '../manager/insights/insights.service';

@Component({
  selector: 'app-resource-enquiries',
  templateUrl: './resource-enquiries.component.html',
  styleUrls: ['./resource-enquiries.component.css']
})
export class ResourceEnquiriesComponent implements OnInit {

  constructor(private insight: InsightService) { }

  ngOnInit(): void {
    this.insight.Visited("ResourceEnquiry").subscribe(
      (item) => {
      },
      (error) => {
        alert("PageVisits Error occured");
      }
      );
  }

}
