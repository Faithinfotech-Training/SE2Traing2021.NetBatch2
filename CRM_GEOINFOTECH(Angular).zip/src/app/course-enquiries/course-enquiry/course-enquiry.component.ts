import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { CourseEnquiry } from 'src/app/shared/course-enquiry.model';
import { CourseEnquiryService } from 'src/app/shared/course-enquiry.service';
import { CourseService } from 'src/app/shared/course.service';
// import { Validators } from '@angular/forms';

@Component({
  selector: 'app-course-enquiry',
  templateUrl: './course-enquiry.component.html',
  styleUrls: ['./course-enquiry.component.css']
})
export class CourseEnquiryComponent implements OnInit {
  enable:boolean;
  courses:any;
  constructor(public service: CourseEnquiryService, private courseService: CourseService) { }

  ngOnInit(): void {
    this.courseService.getCourse().subscribe(res =>{
      this.courses= res;
    })
    if(this.service.courseName.localeCompare("")==0){
      this.enable=true;
    }
    else{
      this.enable=false;
    }
  }

  resetForm() {
    this.service.CourseEnquiry = {
      CourseEnquiryId: 0,
      CourseId: 1,
      UserName: '',
      Email: '',
      PhoneNo: '',
      Dob:new Date("2019-08-05"),
      Qualification: '',
      TestScore: 0,
      EnquiryStatus: "Enquired",
   
    }
  }

  onSubmit(form:NgForm) {
    this.insertRecord(this.service.CourseEnquiry,form);
    
    this.service.courseName="";
  }


  insertRecord(enquiry:CourseEnquiry, form:NgForm) {
    this.service.postCourseEnquiry(enquiry).subscribe(res => {
    
      alert(`Course Enquiry Added Successfully!`);
    },
    (error) =>{
      alert(`Error while submitting Course Enquiry`);
      console.log(error);
    })
    this.resetForm();
    form.reset();
  }
  

}
