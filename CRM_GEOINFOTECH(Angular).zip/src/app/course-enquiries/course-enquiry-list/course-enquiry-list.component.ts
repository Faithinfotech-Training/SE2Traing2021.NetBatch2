import { Component, OnInit, ViewChild } from '@angular/core';
import { FormControl } from '@angular/forms';
import { CourseEnquiryService } from 'src/app/shared/course-enquiry.service';
import {updateStatus} from './updateStatus';
import { Observable, of } from "rxjs";
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { environment } from "src/environments/environment";
import { Router } from '@angular/router';

@Component({
  selector: 'app-course-enquiry-list',
  templateUrl: './course-enquiry-list.component.html',
  styleUrls: ['./course-enquiry-list.component.css']
})
export class CourseEnquiryListComponent implements OnInit {
  status;
  courseEnquiry: any;
  private apiUrl: string = environment.apiUrl;

  registrationViewModel: updateStatus;
  @ViewChild("registrationForm") form: FormControl;

  constructor(public service: CourseEnquiryService, private httpClient: HttpClient, private router: Router) {
    this.registrationViewModel= new updateStatus();
   }

  ngOnInit(): void {
    this.service.getCourseEnquiry().subscribe(res=>{
      this.courseEnquiry=res;
      // console.log(res);
    });
  }

  statusUpdate(): void{
    this.update(this.registrationViewModel.Id,this.registrationViewModel.EnquiryStatus).subscribe(
      (item) => {
        alert(`Updated Successfully`);
      },
      (error) => {
        alert("Status not Updated");
      }
      
    )
    window.location.reload(); 

  }
   update (id:number,status:string): Observable<any> {
    const httpOptions = {
      headers: new HttpHeaders({
        "Content-Type": "application/json",
      }),
    };
    return this.httpClient.put<any>(
      `${this.apiUrl}CourseEnquiry/${id}/status/${status}`,
      httpOptions
    );
  }

}
