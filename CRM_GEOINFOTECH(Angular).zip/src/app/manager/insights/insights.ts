export class PageVisits {
   public Page: String;
   public Views: number;
    constructor(page,views){
        this.Page=page;
        this.Views=views;
    }
  }