﻿using System;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;
using Microsoft.Extensions.Logging;
using Microsoft.IdentityModel.Tokens;
using System.Linq;
using System.Threading.Tasks;
using System.Collections.Generic;
namespace CRMsolution1.Repositories
{
    public class JwtAuthService
    {
        
            private readonly JwtTokenConfig _jwtTokenConfig;
            private readonly ILogger<JwtAuthService> _logger;

            public JwtAuthService(JwtTokenConfig jwtTokenConfig,
                                  ILogger<JwtAuthService> logger)
            {
                _jwtTokenConfig = jwtTokenConfig;
                _logger = logger;
            }

             internal string BuildToken(Claim[] claims)
            {

                var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_jwtTokenConfig.Secret));

                var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

                var token = new JwtSecurityToken(
                        issuer: _jwtTokenConfig.Issuer,
                        audience: _jwtTokenConfig.Audience,
                        notBefore: DateTime.Now,
                        claims: claims,
                        expires: DateTime.Now.AddMinutes(_jwtTokenConfig.AccessTokenExpiration),
                        signingCredentials: creds);

                return new JwtSecurityTokenHandler().WriteToken(token);
            }

            internal string BuildRefreshToken()
            {
            var randomNumber = new byte[32];
            using (var randomNumberGenerator = RandomNumberGenerator.Create())
            {
                randomNumberGenerator.GetBytes(randomNumber);
                return Convert.ToBase64String(randomNumber);
            }
        }

            public ClaimsPrincipal GetPrincipalFromToken(string token)
            {
            JwtSecurityTokenHandler tokenValidator = new JwtSecurityTokenHandler();
            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_jwtTokenConfig.Secret));
            var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

            var parameters = new TokenValidationParameters
            {
                ValidateAudience = false,
                ValidateIssuer = false,
                ValidateIssuerSigningKey = true,
                IssuerSigningKey = key,
                ValidateLifetime = false
            };

            try
            {
                var principal = tokenValidator.ValidateToken(token, parameters, out var securityToken);

                if (!(securityToken is JwtSecurityToken jwtSecurityToken) || !jwtSecurityToken.Header.Alg.Equals(SecurityAlgorithms.HmacSha256, StringComparison.InvariantCultureIgnoreCase))
                {
                    _logger.LogError($"Token validation failed");
                    return null;
                }

                return principal;
            }
            catch (Exception e)
            {
                _logger.LogError($"Token validation failed: {e.Message}");
                return null;
            }

        }
        }

        

        public class JwtTokenConfig
        {
            public string Secret { get; set; }
            public string Issuer { get; set; }
            public string Audience { get; set; }
            public int AccessTokenExpiration { get; set; }
            public int RefreshTokenExpiration { get; set; }

        }

    }




