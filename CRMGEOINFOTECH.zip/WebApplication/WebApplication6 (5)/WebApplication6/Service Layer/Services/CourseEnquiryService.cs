﻿using Domain_Layer.Models;
using Microsoft.EntityFrameworkCore;
using Repository_Layer;
using Repository_Layer.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace Service_Layer.Services
{
    public class CourseEnquiryService : ICourseEnquiry
    {
        private IRepository<CourseEnquiry> _repository;
        private readonly ApplicationDbContext context;
        public CourseEnquiryService(IRepository<CourseEnquiry> repository, ApplicationDbContext context)
        {
            _repository = repository;
            this.context = context;
        }
        public void DeleteCourseEnquiry(int Id)
        {
            CourseEnquiry course = GetCourseEnquiry(Id);
            _repository.Remove(course);
            _repository.SaveChanges();
        }

        public IEnumerable<CourseEnquiry> GetAllCoursesEnquiry()
        {
            return _repository.GetAll();
        }

        public CourseEnquiry GetCourseEnquiry(int id)
        {
            return _repository.Get(id);
        }

        public void InsertCourseEnquiry(CourseEnquiry course)
        {
            _repository.Insert(course);
        }
       
        public void UpdateCourseEnquiry(CourseEnquiry course)
        {
            _repository.Update(course);
        }

        public IEnumerable<CourseEnquiry> getStatusBasedEnquiries(String status)
        {
            return context.CourseEnquiries.Where(enquiry => enquiry.EnquiryStatus.CompareTo(status) == 0).AsEnumerable();
        }



        public void updateEnquiryStatus(int id, String status)
        {
            if (status.Equals("Accepted"))
            {
                var trainee = new Trainee();
                trainee.CourseEnqId = id;
                context.Entry(trainee).State = EntityState.Added;

            }
            var enquiry = context.CourseEnquiries.SingleOrDefault(x => x.CourseEnquiryId==id);
            PropertyInfo propertyInfo = enquiry.GetType().GetProperty("EnquiryStatus");
            propertyInfo.SetValue(enquiry, status);
            context.Entry(enquiry).State = EntityState.Modified;
            context.SaveChanges();
        }

        public CourseEnquirySummary CourseEnquirySummary()
        {
            var c = 0;

            Dictionary<int, int> countMap = new Dictionary<int, int>() ;
            CourseEnquirySummary summary = new CourseEnquirySummary();
            summary.enquired = getStatusBasedEnquiries("Enquired").Count();
            summary.admitted = getStatusBasedEnquiries("Admitted").Count();
            summary.rejected= getStatusBasedEnquiries("Rejected").Count();
            summary.selected = getStatusBasedEnquiries("Selected").Count();
            summary.totalEnquiries = context.CourseEnquiries.ToList().Count();

            var groupedList = context.CourseEnquiries
                       .ToList();
            foreach(var enquiry in groupedList)
            {
                if (countMap.ContainsKey(enquiry.CourseId))
                {
                    countMap[enquiry.CourseId] += 1;
                }
                else
                {
                    countMap.Add(enquiry.CourseId, 1);
                }
            }
            foreach (KeyValuePair<int, int> entry in countMap)
            {
                if (c<entry.Value)
                {
                    c = entry.Value;
                    summary.mostEnquiredCourse = context.Courses.SingleOrDefault(x => x.CourseId == entry.Key).CourseName;
                    summary.highestCourseEnquiries = c;
                }
            }
            return summary;
        }



    }

    public class CourseEnquirySummary
    {
        public String mostEnquiredCourse { get; set; }
        public int highestCourseEnquiries { get; set; } = 0;
        public int enquired { get; set; } = 0;
        public int admitted { get; set; } = 0;
        public int rejected { get; set; } = 0;
        public int selected { get; set; } = 0;
        public int totalEnquiries { get; set; } = 0;
    }
}
