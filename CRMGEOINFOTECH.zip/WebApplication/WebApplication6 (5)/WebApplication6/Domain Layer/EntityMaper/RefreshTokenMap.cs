﻿using Domain_Layer.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain_Layer.EntityMaper
{
    public class RefreshTokenMap: IEntityTypeConfiguration<RefreshToken>
    {
        public void Configure(EntityTypeBuilder<RefreshToken> builder)
        {

            builder.HasKey(e => e.Token)
               .HasName("token");

            builder.Property(e => e.IssuedAt).HasColumnType("datetime").HasColumnName("issuedAt");

            builder.Property(e => e.ExpiresAt).HasColumnType("datetime").HasColumnName("expiresAt");

           
        }
    }
}
