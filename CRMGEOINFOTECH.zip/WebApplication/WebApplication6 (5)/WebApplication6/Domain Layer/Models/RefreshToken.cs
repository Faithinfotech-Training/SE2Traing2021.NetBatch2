﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Domain_Layer.Models
{
    public partial class RefreshToken
    {
        public string Token { get; set; }
        public int? UserId { get; set; }
        public DateTime? IssuedAt { get; set; }
        public DateTime? ExpiresAt { get; set; }
    }
}
