﻿using Domain_Layer.Models;
using System;
using System.Collections.Generic;

#nullable disable

namespace Domain_Layer.Models
{
    public partial class User: BaseEntity
    {   
        public int UserId { get; set; }
        public string UserName { get; set; }
        public string Email { get; set; }
        public string PhoneNo { get; set; }
        public string RolesId { get; set; }
        public string Password { get; set; }
        public bool Accepted { get; set; } = false;

        public virtual Role Role { get; set; }
    }
}
