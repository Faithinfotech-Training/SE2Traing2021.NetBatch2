﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain_Layer.Models
{
    public class Visit
    {
        public int Id { get; set; } = 0;
        public String Page { get; set; }
        public DateTime Day { get; set; } = DateTime.Now;
        public int Views { get; set; } = 1;

    }
}
