﻿using Domain_Layer.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Service_Layer.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication6.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CourseController : ControllerBase
    {
        private readonly CourseService _courseService;

        public CourseController(CourseService courseService)
        {
            _courseService = courseService;
        }

        [HttpGet]
        public IActionResult GetAllCourse()
        {
            var res = _courseService.GetAllCourses();
            if(res is not null)
            {
                return Ok(res);
            }
            return BadRequest("No Record Found");
        }

        [HttpGet("{id}")]
        public IActionResult GetCourse(int id)
        {
            var res = _courseService.GetCourse(id);
            if (res is not null)
            {
                return Ok(res);
            }
            return BadRequest("No Record Found");
        }

        [HttpPost]
        public IActionResult InsertCourse(Course course)
        {
            _courseService.InsertCourse(course);
            return Ok();
        }


        [HttpPut]
        public IActionResult UpdateCourse(Course course)
        {
            _courseService.UpdateCourse(course);
            return Ok();
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteCourse(int id)
        {
            _courseService.DeleteCourse(id);
            return Ok("Data Deleted Successfully");
        }

        [HttpPut("{id}/isActive/{status}")]
        public void updateStatus(int id, int status)
        {
            _courseService.updateCourse(id, "CourseAvailability", Convert.ToBoolean(status));
        }

        [HttpPut("{id}/visibility/{status}")]
        public void updateVisibility(int id, int status)
        {
            _courseService.updateCourse(id, "Visibility", Convert.ToBoolean(status));
        }
        


    }
}
