import { Pipe, PipeTransform } from '@angular/core';
@Pipe({
    name:'search'
})
export class SearchPipe implements PipeTransform {
    transform(languages: any, searchInput: string): any[]{     
        if(!searchInput) {
            return languages;
        }
       searchInput = searchInput.toLowerCase();
       return languages.filter(
           ( x: { courseName: string; }) =>{
               return (x.courseName.toLowerCase().includes(searchInput))
           }
       )
     }
}