import { Component, OnInit } from '@angular/core';
import { CourseService } from 'src/app/shared/course.service';
import { CourseEnquiryService } from 'src/app/shared/course-enquiry.service';

@Component({
  selector: 'app-course-list',
  templateUrl: './course-list.component.html',
  styleUrls: ['./course-list.component.css']
})
export class CourseListComponent implements OnInit {

  course: any;
  searchInput:any;

  constructor(public service:CourseService,private courseEnquiry:CourseEnquiryService) { }

  ngOnInit(): void {
    this.service.getCourse().subscribe(res=>{
      this.course=res;
      // console.log(res);
    });
  }
  populate(id:number,name:String){
    this.courseEnquiry.CourseEnquiry.CourseId=id;
    this.courseEnquiry.courseName=name;
  }

}
