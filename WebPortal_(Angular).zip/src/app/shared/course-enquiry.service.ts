import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { CourseEnquiry } from './course-enquiry.model';


@Injectable({
  providedIn: 'root'
})
export class CourseEnquiryService {
 
  public courseName:String="";
  public CourseEnquiry:CourseEnquiry=new CourseEnquiry();
  
  
  formData: CourseEnquiry = new CourseEnquiry;
  readonly rootURL="https://localhost:44367/api/CourseEnquiry";

  constructor(private http:HttpClient) { }
  getCourseEnquiry()
  {
    return this.http.get(this.rootURL);
  }

  postCourseEnquiry(formData:CourseEnquiry)
  {
    alert("Course Enquiry Added Successfully!");
    return this.http.post(this.rootURL,formData);
  }
}
