import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ResourceEnquiry } from 'src/app/shared/resource-enquiry.model';
import { ResourceEnquiryService } from 'src/app/shared/resource-enquiry.service';
import { ResourceService } from 'src/app/shared/resource.service';

@Component({
  selector: 'app-resource-enquiry',
  templateUrl: './resource-enquiry.component.html',
  styleUrls: ['./resource-enquiry.component.css']
})
export class ResourceEnquiryComponent implements OnInit {

  enable:boolean;
  resources:any;
  constructor(public service: ResourceEnquiryService, private resourceService: ResourceService) { }

  ngOnInit(): void {
    this.resourceService.getResource().subscribe(res =>{
      this.resources= res;
    })
    if(this.service.resourceName.localeCompare("")==0){
      this.enable=true;
    }
    else{
      this.enable=false;
    }

  }

  resetForm() {
    this.service.ResourceEnquiry = {
      ResourceEnqId: 0,
      ResourceId: 1,
      UserName: '',
      Email: '',
      PhoneNo: '',
      EnquiryStatus: "Vacant",
   
    }
  }

  onSubmit(form: NgForm) {
    this.insertRecord(form, this.service.ResourceEnquiry);
    this.service.resourceName="";
  }

  insertRecord(form: NgForm,enquiry:ResourceEnquiry) {
    this.service.postResourceEnquiry(enquiry).subscribe(res => {
      alert(`Resource equiry submitted successfully`);
    },
    (error) =>{
      alert(`Error occured while submitting enquiry`);
    })
    this.resetForm();
    form.reset();
  }
}
