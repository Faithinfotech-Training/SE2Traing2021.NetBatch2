import { Component, OnInit } from '@angular/core';
import { ResourceEnquiryService } from 'src/app/shared/resource-enquiry.service';
import { Router } from '@angular/router';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-resource-enquiry-list',
  templateUrl: './resource-enquiry-list.component.html',
  styleUrls: ['./resource-enquiry-list.component.css']
})
export class ResourceEnquiryListComponent implements OnInit {

  resourceEnquiry: any;


  constructor(public service:ResourceEnquiryService, private router:ActivatedRoute) { }

  ngOnInit(): void {
    this.service.getResourceEnquiry().subscribe(res=>{
      this.resourceEnquiry=res;
      // console.log(res);
    });
  }

  deleteResEnq(){
    this.service.deleteResourceEnquiry(this.router.snapshot.params.resourceId).subscribe();
  }

}
