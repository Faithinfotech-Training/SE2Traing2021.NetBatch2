import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-resource-enquiries',
  templateUrl: './resource-enquiries.component.html',
  styleUrls: ['./resource-enquiries.component.css']
})
export class ResourceEnquiriesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
