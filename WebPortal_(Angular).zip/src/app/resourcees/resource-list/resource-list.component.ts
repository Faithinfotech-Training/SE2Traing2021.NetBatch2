import { Component, OnInit } from '@angular/core';
import { ResourceService } from 'src/app/shared/resource.service';
import { ResourceEnquiryService } from 'src/app/shared/resource-enquiry.service';

@Component({
  selector: 'app-resource-list',
  templateUrl: './resource-list.component.html',
  styleUrls: ['./resource-list.component.css']
})
export class ResourceListComponent implements OnInit {
  resource: any;
  searchInput:any;
  constructor(public service:ResourceService,private enquiryService:ResourceEnquiryService) { }

  ngOnInit(): void {
    this.service.getResource().subscribe(res=>{
      this.resource=res;
      // console.log(res);
    });
  }
  populate(id:number,name:String){
    this.enquiryService.ResourceEnquiry.ResourceId=id;
    this.enquiryService.resourceName=name;
  }

}
