import { Pipe, PipeTransform } from '@angular/core';
@Pipe({
    name:'searchR'
})
export class SearchRPipe implements PipeTransform {
    transform(languages: any, searchInput: string): any[]{     
        if(!searchInput) {
            return languages;
        }
       searchInput = searchInput.toLowerCase();
       return languages.filter(
           ( x: { resourceName: string; }) =>{
               return (x.resourceName.toLowerCase().includes(searchInput))
           }
       )
     }
}