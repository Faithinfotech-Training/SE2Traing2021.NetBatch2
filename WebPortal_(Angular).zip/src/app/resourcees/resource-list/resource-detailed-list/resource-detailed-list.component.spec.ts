import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ResourceDetailedListComponent } from './resource-detailed-list.component';

describe('ResourceDetailedListComponent', () => {
  let component: ResourceDetailedListComponent;
  let fixture: ComponentFixture<ResourceDetailedListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ResourceDetailedListComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ResourceDetailedListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
