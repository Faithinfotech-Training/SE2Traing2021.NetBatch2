import { Component, OnInit } from '@angular/core';
import { CourseEnquiry } from '../shared/course-enquiry.model';
import { CourseEnquiryService } from '../shared/course-enquiry.service';

@Component({
  selector: 'app-course-enquiries',
  templateUrl: './course-enquiries.component.html',
  styleUrls: ['./course-enquiries.component.css']
})
export class CourseEnquiriesComponent implements OnInit {
  constructor(public service:CourseEnquiryService) { }

  ngOnInit(): void {
    
  }

}
