import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';


import { CourseEnquiriesComponent } from './course-enquiries/course-enquiries.component';
import { CourseEnquiryComponent } from './course-enquiries/course-enquiry/course-enquiry.component';
import { CourseComponent } from './courses/course/course.component';
import { CoursesComponent } from './courses/courses.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { ManagerComponent } from './manager/manager.component';
import { ResourceEnquiriesComponent } from './resource-enquiries/resource-enquiries.component';
import { ResourceEnquiryComponent } from './resource-enquiries/resource-enquiry/resource-enquiry.component';
import { ResourceComponent } from './resourcees/resource/resource.component';
import { ResourceesComponent } from './resourcees/resourcees.component';

const routes: Routes = [
  {path:'courses',component:CoursesComponent
    // children: [
    //   {path:'course',component:CourseComponent}
    // ]
  },
  {path:"courses/course",component:CourseComponent},
  {path:"courseEnquiries",component:CourseEnquiriesComponent},
  {path:"courseEnquiries/courseEnquiry",component:CourseEnquiryComponent},

  {path:'resources',component:ResourceesComponent},
  {path:'resources/resource',component:ResourceComponent},
  {path:"resourceEnquiries",component:ResourceEnquiriesComponent},
  {path:"resourceEnquiries/resourceEnquiry",component:ResourceEnquiryComponent},
  
  {path:'manage',component:ManagerComponent},

  {path:'',component:DashboardComponent},


];

@NgModule({
  imports: [CommonModule,RouterModule.forRoot(routes),RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
