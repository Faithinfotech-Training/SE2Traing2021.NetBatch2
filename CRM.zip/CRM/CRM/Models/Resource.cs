﻿/*using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CRM.Models
{
    public partial class Resource
    {
        public int ResourceId { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public string Type { get; set; }
        public int Price { get; set; }
        public bool Visibility { get; set; }
        public bool IsActive { get; set; }

        public virtual ICollection<ResourceEnquiry> ResourceEnquiries { get; set; }
    }
}*/



using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace CRM.Models
{
    public partial class Resource
    {
        public Resource()
        {
            //Batches = new HashSet<Batch>();
            ResourceEnquiry = new HashSet<ResourceEnquiry>();
        }

        public int ResourceId { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public string Type { get; set; }
        public int Price { get; set; }
        public bool Visibility { get; set; }
        public bool IsActive { get; set; }

        //public virtual ICollection<Batch> Batches { get; set; }
        [NotMapped]
        public virtual ICollection<ResourceEnquiry> ResourceEnquiry { get; set; }


    }
}
