import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ResourceEnquiryService } from 'src/app/shared/resource-enquiry.service';

@Component({
  selector: 'app-resource-enquiry',
  templateUrl: './resource-enquiry.component.html',
  styleUrls: ['./resource-enquiry.component.css']
})
export class ResourceEnquiryComponent implements OnInit {

  constructor(public service: ResourceEnquiryService) { }

  ngOnInit(): void {
    this.resetForm();
  }

  resetForm(form?: NgForm) {
    if (form != null)
      form.resetForm();
    this.service.formData = {
      ResourceEnqId: 0,
      ResourceId: this.service.resourceId,
      UserName: '',
      Email: '',
      PhoneNo: '',
      EnquiryStatus: "Vacant",
   
    }
  }

  onSubmit(form: NgForm) {
    this.insertRecord(form);
  }

  insertRecord(form: NgForm) {
    this.service.postResourceEnquiry(form.value).subscribe(res => {
      this.resetForm(form);
    })
  }

}
