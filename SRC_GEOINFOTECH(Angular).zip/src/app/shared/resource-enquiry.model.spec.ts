import { ResourceEnquiry } from './resource-enquiry.model';

describe('ResourceEnquiry', () => {
  it('should create an instance', () => {
    expect(new ResourceEnquiry()).toBeTruthy();
  });
});
