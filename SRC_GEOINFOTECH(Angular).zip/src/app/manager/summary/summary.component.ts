import { Component, OnInit } from '@angular/core';
import { Observable, of } from "rxjs";
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { environment } from "src/environments/environment";

@Component({
  selector: 'app-summary',
  templateUrl: './summary.component.html',
  styleUrls: ['./summary.component.css']
})
export class SummaryComponent implements OnInit {
  c;
  r;
  private apiUrl: string = environment.apiUrl;
  constructor(private httpClient: HttpClient) {}


  ngOnInit(): void {
    this.getSummary("CourseEnquiry").subscribe(res =>{
      this.c= res;
    });
    this.getSummary("ResourceEnquiry").subscribe(res =>{
      this.r=res;
    })
  }
  public getSummary(controller: String): Observable<any> {
    return this.httpClient.get<any>(
      `${this.apiUrl}${controller}/insights`
    );
  }

}
