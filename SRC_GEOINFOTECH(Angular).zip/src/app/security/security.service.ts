import { Injectable } from "@angular/core";
import { environment } from "src/environments/environment";
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Observable } from "rxjs";
import { Login } from "../account/login/Login";
import { tap } from "rxjs/operators";

@Injectable({
  providedIn: "root",
})
export class SecurityService {
  login:boolean=false;
  private apiUrl: string = environment.apiUrl;
  constructor(private httpClient: HttpClient) {}
 

  public getUserDetails(): Observable<any[]> {
    return this.httpClient.get<any[]>(`${this.apiUrl}userdetails`);
  }

  public Login(userForm: Login): Observable<any> {
    const httpOptions = {
      headers: new HttpHeaders({
        "Content-Type": "application/json",
      }),
    };
    return this.httpClient
      .post(
        `${this.apiUrl}Accounts/login`,
        userForm,
        httpOptions
      )
  }

  roleMatch(allowedRoles): boolean {
    var isMatch = false;
    var payLoad = JSON.parse(window.atob(localStorage.getItem('token').split('.')[1]));
    console.log(payLoad);
    var userRole = payLoad.role;
    allowedRoles.forEach(element => {
      if (userRole == element) {
        isMatch = true;
      }
    });
     
    return isMatch;
  } 
}