import { Injectable } from "@angular/core";
import {
  CanActivateChild,
  CanActivate,
  ActivatedRouteSnapshot,
  RouterStateSnapshot,
  UrlTree,
  Router,
} from "@angular/router";
import { Observable } from "rxjs";
import { SecurityService } from "./security.service";

@Injectable({
  providedIn: "root",
})
export class AuthGuard implements CanActivate {

  constructor(private router: Router,private service:SecurityService) {
  }
  canActivate(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): boolean {
    if (localStorage.getItem('token') != null){
      let roles=next.data['permittedRoles'] as Array<string>;
      if(roles){
        //console.log(`Role is ${roles}`)
        if(this.service.roleMatch(roles)){
        console.log(`Role is ${roles}`);
         return true;}
        else{
          this.router.navigate(['/forbidden'])
          return false;
        }
      }
      return true;
    }
    else {
      this.router.navigate(['/login']);
      return false;
    }

  }
  
}