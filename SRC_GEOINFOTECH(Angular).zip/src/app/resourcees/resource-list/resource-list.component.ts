import { Component, OnInit } from '@angular/core';
import { ResourceEnquiryService } from 'src/app/shared/resource-enquiry.service';
import { ResourceService } from 'src/app/shared/resource.service';
import { UpdateServiceService } from 'src/app/shared/update-service.service';

@Component({
  selector: 'app-resource-list',
  templateUrl: './resource-list.component.html',
  styleUrls: ['./resource-list.component.css']
})
export class ResourceListComponent implements OnInit {
  resource: any;
  searchInput:String;

  constructor(public service:ResourceService, private enquiryService: ResourceEnquiryService, private updateservice: UpdateServiceService) { }

  ngOnInit(): void {
    this.service.getResource().subscribe(res=>{
      this.resource=res;
      // console.log(res);
    });
  }

  populate(id:number): void{
    this.enquiryService.resourceId=id;
  }

  update(course:any):void{
    this.updateservice.Resource.ResourceId= course.resourceId;
    this.updateservice.Resource.ResourceName= course.resourceName;
    this.updateservice.Resource.ResourceDesc= course.resourceDesc;
    this.updateservice.Resource.Type= course.type;
    this.updateservice.Resource.ResourcePrice= course.resourcePrice;
    this.updateservice.Resource.Visibility= course.visibility;
  }

}
