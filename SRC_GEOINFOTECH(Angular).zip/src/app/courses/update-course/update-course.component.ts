import { Component, OnInit } from '@angular/core';
import { UpdateServiceService } from 'src/app/shared/update-service.service';


@Component({
  selector: 'app-update-course',
  templateUrl: './update-course.component.html',
  styleUrls: ['./update-course.component.css']
})
export class UpdateCourseComponent implements OnInit {

  constructor(public service: UpdateServiceService) { }

  ngOnInit(): void {
    console.log(this.service.Course);
  }

  updateCourse():void{
    this.service.update("Course",this.service.Course).subscribe((res) =>{
        alert(`Course Updated Successfully`);
      },
      (error) =>{
          alert(`Error occured while updating the course`);
        }
      
    );
  
   }
}
