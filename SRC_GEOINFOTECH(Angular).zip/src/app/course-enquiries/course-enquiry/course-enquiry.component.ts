import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { CourseEnquiryService } from 'src/app/shared/course-enquiry.service';
// import { Validators } from '@angular/forms';

@Component({
  selector: 'app-course-enquiry',
  templateUrl: './course-enquiry.component.html',
  styleUrls: ['./course-enquiry.component.css']
})
export class CourseEnquiryComponent implements OnInit {

  constructor(public service: CourseEnquiryService) { }

  ngOnInit(): void {
    this.resetForm();
  }

  resetForm(form?: NgForm) {
    if (form != null)
      form.resetForm();
    this.service.formData = {
      CourseEnquiryId: 0,
      CourseId: this.service.CourseId,
      UserName: '',
      Email: '',
      PhoneNo: '',
      Dob:new Date("2019-08-05"),
      Qualification: '',
      TestScore: 0,
      EnquiryStatus: "Enquired",
   
    }
  }

  onSubmit(form: NgForm) {
    this.insertRecord(form);
  }

  insertRecord(form: NgForm) {
    this.service.postCourseEnquiry(form.value).subscribe(res => {
      this.resetForm(form);
    })
  }

}
