import { Component, OnInit } from '@angular/core';
import { InsightService } from '../manager/insights/insights.service';
import { CourseEnquiry } from '../shared/course-enquiry.model';
import { CourseEnquiryService } from '../shared/course-enquiry.service';

@Component({
  selector: 'app-course-enquiries',
  templateUrl: './course-enquiries.component.html',
  styleUrls: ['./course-enquiries.component.css']
})
export class CourseEnquiriesComponent implements OnInit {
  constructor(public service:CourseEnquiryService, private insight: InsightService) { }

  ngOnInit(): void {
    this.insight.Visited("CourseEnquiry").subscribe(
      (item) => {
      },
      (error) => {
        alert("PageVisits Error occured");
      }
      );
    
  }

}
