export interface Login {
    UserName: string;
    Password: string;
  }